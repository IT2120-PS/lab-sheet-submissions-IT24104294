setwd("D:/Other/University/LabSheet/2Y_1st_SEM/PS/Lab02")

x<-c(1,2,3)
numerator <-x[1]
denominator<-x[2]^3-1+2*x[3]-x[2-1]
result <- numerator  / denominator
result

y<-c(1:15)
nElem<-0
for(i in y){
  if(i%%3==0){
    nElem<-nElem+1
    print(i)
  }
}
nElem

z<-sample(c(1:10))
z
maxN<-z[1]
maxN
for(i in 1:length(z)){
  if(z[i]>maxN){
    maxN<-z[i]
  }
}
maxN

f<-sample(c(2:20), replace = TRUE)
f
max(f)
